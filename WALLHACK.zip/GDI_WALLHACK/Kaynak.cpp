#include "arac.h"
int main()
{
    renk = CreateSolidBrush(RGB(255, 0, 0));
    int oyuncusayi;
    HWND window = FindWindow(0, L"AssaultCube");
    hdcAC = GetDC(window);
    DWORD pid;
    GetWindowThreadProcessId(window, &pid);
    HANDLE hnd = OpenProcess(PROCESS_ALL_ACCESS, false, pid);
    if (!hnd)
    {
        cout << "Hata Olustu" << endl;
        Sleep(500);
        exit(0);
    }
    DWORD moduleadres = GetModuleBaseAddress(pid, L"ac_client.exe");
    DWORD entitybase = moduleadres + entitybasep;
    DWORD oyuncusayiadres = moduleadres + oyuncusayip;
    ReadProcessMemory(hnd, (LPVOID)oyuncusayiadres, &oyuncusayi, 4, 0);
    float viewMatrix[16];
    DWORD entitytemp;
    DWORD entitylast;
    while (true)
    {
        for (int a = 1; a <= oyuncusayi; a++)
        {
            ReadProcessMemory(hnd, (LPVOID)(moduleadres + viewmatrixp), &viewMatrix, sizeof(viewMatrix), 0);
            ReadProcessMemory(hnd, (LPVOID)(entitybase),&entitytemp,4,0);
            ReadProcessMemory(hnd, (LPVOID)(entitytemp+a*4), &entitylast, 4, 0);
            ReadProcessMemory(hnd, (LPVOID)(entitylast + offsetx[0]), &enemyb.x, 4, 0);
            ReadProcessMemory(hnd, (LPVOID)(entitylast + offsety[0]), &enemyb.y, 4, 0);
            ReadProcessMemory(hnd, (LPVOID)(entitylast + offsetz[0]), &enemyb.z, 4, 0);
            ReadProcessMemory(hnd, (LPVOID)(entitylast + kafax[0]), &enemyh.x, 4, 0);
            ReadProcessMemory(hnd, (LPVOID)(entitylast + kafay[0]), &enemyh.y, 4, 0);
            ReadProcessMemory(hnd, (LPVOID)(entitylast + kafaz[0]), &enemyh.z, 4, 0);
            ESP(enemyb, enemyh, viewMatrix);
        }
        Sleep(1);
    }
}